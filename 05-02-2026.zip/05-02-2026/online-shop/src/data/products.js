export const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 79.99,
    description: "High-quality wireless headphones with noise cancellation and 30-hour battery life.",
    category: "Electronics",
    image: "🎧"
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 199.99,
    description: "Feature-packed smartwatch with fitness tracking, heart rate monitor, and GPS.",
    category: "Electronics",
    image: "⌚"
  },
  {
    id: 3,
    name: "Laptop Backpack",
    price: 49.99,
    description: "Durable backpack with padded laptop compartment and multiple pockets.",
    category: "Accessories",
    image: "🎒"
  },
  {
    id: 4,
    name: "Mechanical Keyboard",
    price: 129.99,
    description: "RGB mechanical keyboard with customizable keys and tactile switches.",
    category: "Electronics",
    image: "⌨️"
  },
  {
    id: 5,
    name: "Wireless Mouse",
    price: 39.99,
    description: "Ergonomic wireless mouse with precision tracking and long battery life.",
    category: "Electronics",
    image: "🖱️"
  },
  {
    id: 6,
    name: "USB-C Hub",
    price: 59.99,
    description: "Multi-port USB-C hub with HDMI, USB 3.0, and SD card reader.",
    category: "Accessories",
    image: "🔌"
  }
];
