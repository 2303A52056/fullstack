import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import Navigation from './components/Navigation';
import Home from './components/Home';
import Products from './components/Products';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import './App.css';

function App() {
  return (
    <CartProvider>
      <Router>
        <div className="App">
          <Navigation />
          <main className="main-content">
            <Routes>
              {/* Main Routes */}
              <Route path="/" element={<Home />} />
              
              {/* Nested Routes - Products with ProductDetail as nested route */}
              <Route path="/products" element={<Products />}>
                <Route path=":id" element={<ProductDetail />} />
              </Route>
              
              <Route path="/cart" element={<Cart />} />
              
              {/* 404 Not Found Route */}
              <Route path="*" element={
                <div style={{ textAlign: 'center', padding: '50px' }}>
                  <h1>404 - Page Not Found</h1>
                  <p>The page you're looking for doesn't exist.</p>
                </div>
              } />
            </Routes>
          </main>
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;
