import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import { products } from '../data/products';
import './Products.css';

const Products = () => {
  return (
    <div className="products-container">
      <h1>Our Products</h1>
      <div className="products-grid">
        {products.map((product) => (
          <Link 
            to={`/products/${product.id}`} 
            key={product.id} 
            className="product-card"
          >
            <div className="product-image">{product.image}</div>
            <h3>{product.name}</h3>
            <p className="product-category">{product.category}</p>
            <p className="product-price">${product.price}</p>
            <button className="view-details-btn">View Details</button>
          </Link>
        ))}
      </div>
      
      {/* Outlet for nested routes (ProductDetail) */}
      <Outlet />
    </div>
  );
};

export default Products;
