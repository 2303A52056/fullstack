import React, { useContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { products } from '../data/products';
import { CartContext } from '../context/CartContext';
import './ProductDetail.css';

const ProductDetail = () => {
  const { id } = useParams(); // Using useParams to get the product ID from URL
  const navigate = useNavigate();
  const { addToCart } = useContext(CartContext);
  
  // Find the product by ID
  const product = products.find(p => p.id === parseInt(id));
  
  // If product not found, show error message
  if (!product) {
    return (
      <div className="product-detail-modal">
        <div className="product-detail-content">
          <h2>Product Not Found</h2>
          <p>The product you're looking for doesn't exist.</p>
          <button onClick={() => navigate('/products')} className="back-btn">
            Back to Products
          </button>
        </div>
      </div>
    );
  }
  
  const handleAddToCart = () => {
    addToCart(product);
    alert(`${product.name} added to cart!`);
  };
  
  return (
    <div className="product-detail-modal" onClick={() => navigate('/products')}>
      <div className="product-detail-content" onClick={(e) => e.stopPropagation()}>
        <button className="close-btn" onClick={() => navigate('/products')}>
          ✕
        </button>
        
        <div className="product-detail-layout">
          <div className="product-detail-image">
            {product.image}
          </div>
          
          <div className="product-detail-info">
            <span className="product-detail-category">{product.category}</span>
            <h2>{product.name}</h2>
            <p className="product-detail-price">${product.price}</p>
            <p className="product-detail-description">{product.description}</p>
            
            <div className="product-detail-meta">
              <p><strong>Product ID:</strong> {product.id}</p>
              <p><strong>Category:</strong> {product.category}</p>
            </div>
            
            <div className="product-detail-actions">
              <button onClick={handleAddToCart} className="add-to-cart-btn">
                Add to Cart 🛒
              </button>
              <Link to="/cart" className="go-to-cart-btn">
                Go to Cart
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
