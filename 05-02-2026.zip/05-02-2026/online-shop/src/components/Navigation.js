import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import './Navigation.css';

const Navigation = () => {
  const { cart } = useContext(CartContext);
  
  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0);
  
  return (
    <nav className="navbar">
      <div className="nav-container">
        <NavLink to="/" className="nav-logo">
          🛍️ Online Shop
        </NavLink>
        
        <div className="nav-links">
          <NavLink 
            to="/" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Home
          </NavLink>
          <NavLink 
            to="/products" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Products
          </NavLink>
          <NavLink 
            to="/cart" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Cart
            {cartItemsCount > 0 && (
              <span className="cart-badge">{cartItemsCount}</span>
            )}
          </NavLink>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
