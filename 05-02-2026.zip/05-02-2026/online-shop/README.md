# Online Shop SPA - React Router Project
**Date: 05-02-2026**

A modern, fully-functional online shop Single Page Application built with React and React Router, featuring routing, nested routes, dynamic URL parameters, and global state management.

## 🎯 Features

### Core Features
- ✅ **React Router v6** - Complete routing implementation
- ✅ **Nested Routes** - Product details as nested route under products
- ✅ **Dynamic URL Parameters** - Using `useParams()` hook to fetch product ID
- ✅ **Global Cart State** - Context API for cart management
- ✅ **Responsive Design** - Mobile-friendly interface
- ✅ **Modern UI** - Beautiful gradient designs and animations

### Pages
1. **Home** - Landing page with hero section and features
2. **Products** - Product grid with navigation to details
3. **Product Detail** - Modal view with dynamic data based on URL parameter
4. **Cart** - Shopping cart with quantity management

## 📂 Project Structure

```
online-shop-05-02-2026/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Home.js
│   │   ├── Home.css
│   │   ├── Products.js
│   │   ├── Products.css
│   │   ├── ProductDetail.js
│   │   ├── ProductDetail.css
│   │   ├── Cart.js
│   │   ├── Cart.css
│   │   ├── Navigation.js
│   │   └── Navigation.css
│   ├── context/
│   │   └── CartContext.js
│   ├── data/
│   │   └── products.js
│   ├── App.js
│   ├── App.css
│   ├── index.js
│   └── index.css
├── package.json
└── README.md
```

## 🚀 Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation Steps

1. **Extract the project files**
   ```bash
   unzip online-shop-05-02-2026.zip
   cd online-shop-05-02-2026
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```

4. **Open in browser**
   - The app will automatically open at `http://localhost:3000`

## 🛠️ Technical Implementation

### Routing Configuration

The app uses React Router v6 with the following route structure:

```javascript
<Routes>
  <Route path="/" element={<Home />} />
  
  {/* Nested Routes */}
  <Route path="/products" element={<Products />}>
    <Route path=":id" element={<ProductDetail />} />
  </Route>
  
  <Route path="/cart" element={<Cart />} />
</Routes>
```

### Nested Route Implementation

**Products.js** uses `<Outlet />` to render nested routes:
```javascript
import { Outlet } from 'react-router-dom';

const Products = () => {
  return (
    <div>
      {/* Product Grid */}
      <Outlet /> {/* Renders ProductDetail when URL matches /products/:id */}
    </div>
  );
};
```

### Dynamic URL Parameters (useParams)

**ProductDetail.js** uses `useParams()` to access the product ID:
```javascript
import { useParams } from 'react-router-dom';

const ProductDetail = () => {
  const { id } = useParams(); // Extracts :id from URL
  const product = products.find(p => p.id === parseInt(id));
  
  return (
    // Display product details dynamically
  );
};
```

### Navigation

**Navigation.js** uses `NavLink` for active route styling:
```javascript
<NavLink 
  to="/products" 
  className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
>
  Products
</NavLink>
```

## 🎨 Features Demonstration

### 1. Main Routes
- `/` - Home page
- `/products` - Products listing
- `/cart` - Shopping cart

### 2. Nested Routes
- `/products/1` - Product detail for product ID 1
- `/products/2` - Product detail for product ID 2
- etc.

### 3. Dynamic Routing
- Click any product card to navigate to `/products/:id`
- Product details are fetched based on the URL parameter
- Modal overlay displays product information

### 4. Cart Functionality
- Add products to cart from product details
- Update quantities in cart
- Remove items from cart
- Real-time total calculation

## 📦 Dependencies

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "react-router-dom": "^6.20.0",
  "react-scripts": "5.0.1"
}
```

## 🎯 Bonus Challenge Completion

✅ **useParams() Implementation**
- Successfully extracts product ID from URL
- Dynamically fetches and displays product data

✅ **Nested Routes**
- Product details rendered as nested route
- Proper use of `<Outlet />` component

✅ **URL Parameter Handling**
- Product details change based on URL
- Fallback for invalid product IDs

## 📱 Responsive Design

The application is fully responsive and works on:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (< 768px)

## 🔑 Key Learning Points

1. **React Router v6 Basics**
   - Route configuration
   - Navigation between pages
   - NavLink vs Link

2. **Nested Routes**
   - Parent-child route relationships
   - Outlet component usage
   - Route hierarchy

3. **URL Parameters**
   - useParams() hook
   - Dynamic route matching
   - Parameter extraction

4. **State Management**
   - Context API for global state
   - Cart state management
   - Provider pattern

## 🚀 Available Scripts

- `npm start` - Runs the app in development mode
- `npm build` - Builds the app for production
- `npm test` - Runs the test suite
- `npm eject` - Ejects from Create React App

## 📝 Notes

- All product data is stored in `src/data/products.js`
- Cart state is managed globally using React Context
- Product details display as modal overlay
- Navigation is sticky for better UX

## 🎓 Expected Output Achieved

✅ SPA with multiple pages working correctly
✅ Nested route functionality implemented
✅ Dynamic product details display using URL params
✅ Professional, modern UI design
✅ Fully responsive layout
✅ Cart functionality with state management

## 📧 Author

Created on: **05-02-2026**

---

**Happy Coding! 🚀**
